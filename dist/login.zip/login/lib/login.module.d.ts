export declare class LoginModule {
}

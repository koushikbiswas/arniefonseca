export declare class ContactusService {
    constructor();
}

import { OnInit } from '@angular/core';
import { Router } from '@angular/router';
export declare class LoadingComponent implements OnInit {
    private router;
    loading: any;
    constructor(router: Router);
    ngOnInit(): void;
}

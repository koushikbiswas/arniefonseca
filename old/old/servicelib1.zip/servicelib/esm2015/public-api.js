/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of servicelib
 */
export { ServicelibService } from './lib/servicelib.service';
export { ServicelibComponent } from './lib/servicelib.component';
export { ServicelibModule } from './lib/servicelib.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL3NlcnZpY2VsaWIvIiwic291cmNlcyI6WyJwdWJsaWMtYXBpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFJQSxrQ0FBYywwQkFBMEIsQ0FBQztBQUN6QyxvQ0FBYyw0QkFBNEIsQ0FBQztBQUMzQyxpQ0FBYyx5QkFBeUIsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2Ygc2VydmljZWxpYlxuICovXG5cbmV4cG9ydCAqIGZyb20gJy4vbGliL3NlcnZpY2VsaWIuc2VydmljZSc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9zZXJ2aWNlbGliLmNvbXBvbmVudCc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9zZXJ2aWNlbGliLm1vZHVsZSc7XG4iXX0=
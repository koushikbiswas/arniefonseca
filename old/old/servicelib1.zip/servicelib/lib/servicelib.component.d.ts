import { OnInit } from '@angular/core';
export declare class ServicelibComponent implements OnInit {
    serviceListConfig: any;
    loader: boolean;
    config: any;
    constructor();
    ngOnInit(): void;
}

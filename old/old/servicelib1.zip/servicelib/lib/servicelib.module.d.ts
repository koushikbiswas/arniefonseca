export declare class ServicelibModule {
}

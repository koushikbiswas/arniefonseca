/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { AddeditServiceComponent as ɵa, Modal as ɵb } from './lib/Component/addedit-service/addedit-service.component';
export { DemoMaterialModule as ɵc } from './lib/modules/material-module';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of testimonial
 */
export { TestimonialService } from './lib/testimonial.service';
export { TestimonialComponent } from './lib/testimonial.component';
export { TestimonialModule } from './lib/testimonial.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL3Rlc3RpbW9uaWFsLyIsInNvdXJjZXMiOlsicHVibGljLWFwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBSUEsbUNBQWMsMkJBQTJCLENBQUM7QUFDMUMscUNBQWMsNkJBQTZCLENBQUM7QUFDNUMsa0NBQWMsMEJBQTBCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogUHVibGljIEFQSSBTdXJmYWNlIG9mIHRlc3RpbW9uaWFsXG4gKi9cblxuZXhwb3J0ICogZnJvbSAnLi9saWIvdGVzdGltb25pYWwuc2VydmljZSc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi90ZXN0aW1vbmlhbC5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvdGVzdGltb25pYWwubW9kdWxlJztcbiJdfQ==
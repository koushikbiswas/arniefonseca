import { OnInit } from '@angular/core';
export declare class TestimonialComponent implements OnInit {
    testimonialListConfig: any;
    loader: boolean;
    config: any;
    constructor();
    ngOnInit(): void;
}

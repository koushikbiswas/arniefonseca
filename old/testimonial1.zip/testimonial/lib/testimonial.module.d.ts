export declare class TestimonialModule {
}

/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { AddeditComponent as ɵa, Modal as ɵb } from './lib/Components/addedit/addedit.component';
export { DemoMaterialModule as ɵc } from './lib/Modules/material-module';
